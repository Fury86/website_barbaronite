import "server-only";
import { and, asc, desc, eq, gte, isNotNull, lt, or, sql } from "drizzle-orm";
import {
  db,
  activities,
  teamMembers,
  scheduleSeasons,
  scheduleSlots,
  events,
  posts,
  pageBlocks,
  settings,
} from "@/db";
import { todayISO } from "./format";

// ---------- Настройки ----------
export const DEFAULT_SETTINGS: Record<string, string> = {
  site_name: "БарбарониТЕ",
  tagline: "Творчески център за деца и възрастни – изкуство, музика и вдъхновение.",
  address: "ул. Васил Кънчев 26, ж.к. Хаджи Димитър, София",
  phone: "+359 887 865 073",
  email: "info@barbaronite.eu",
  notify_email: "info@barbaronite.eu",
  facebook: "https://www.facebook.com/barbaronitesofia/",
  instagram: "",
  youtube: "",
  maps_url: "https://maps.google.com/?q=ул.+Васил+Кънчев+26,+София",
  meta_title: "БарбарониТЕ – творчески център за деца и възрастни в София",
  meta_description:
    "Пиано, пеене, китара, актьорско майсторство, рисуване, български език и математика за деца и възрастни в ж.к. Хаджи Димитър, София.",
};

export async function getSettings(): Promise<Record<string, string>> {
  const rows = await db.select().from(settings);
  const out = { ...DEFAULT_SETTINGS };
  for (const r of rows) out[r.key] = r.value;
  return out;
}

export async function getSetting(key: string): Promise<string> {
  const [r] = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
  return r?.value ?? DEFAULT_SETTINGS[key] ?? "";
}

// ---------- Текстове ----------
export async function getBlocks(page?: string): Promise<Record<string, string>> {
  const rows = page
    ? await db.select().from(pageBlocks).where(eq(pageBlocks.page, page))
    : await db.select().from(pageBlocks);
  const out: Record<string, string> = {};
  for (const r of rows) out[r.key] = r.content;
  return out;
}

// ---------- Дейности ----------
export async function getVisibleActivities() {
  return db
    .select()
    .from(activities)
    .where(eq(activities.visible, true))
    .orderBy(asc(activities.sortOrder), asc(activities.id));
}

export async function getActivityBySlug(slug: string) {
  const [a] = await db.select().from(activities).where(eq(activities.slug, slug)).limit(1);
  return a ?? null;
}

// ---------- Екип ----------
export async function getVisibleTeam() {
  return db
    .select()
    .from(teamMembers)
    .where(eq(teamMembers.visible, true))
    .orderBy(asc(teamMembers.sortOrder), asc(teamMembers.id));
}

// ---------- Програма ----------
export type SlotView = {
  id: number;
  weekday: number;
  startTime: string;
  endTime: string;
  title: string;
  activitySlug: string | null;
  color: string;
  teacher: string;
  groupLabel: string;
  room: string;
};

export async function getActiveSchedule(): Promise<{ season: typeof scheduleSeasons.$inferSelect | null; slots: SlotView[] }> {
  const [season] = await db.select().from(scheduleSeasons).where(eq(scheduleSeasons.active, true)).limit(1);
  if (!season) return { season: null, slots: [] };
  const slots = await getSeasonSlots(season.id);
  return { season, slots };
}

export async function getSeasonSlots(seasonId: number): Promise<SlotView[]> {
  const rows = await db
    .select({
      id: scheduleSlots.id,
      weekday: scheduleSlots.weekday,
      startTime: scheduleSlots.startTime,
      endTime: scheduleSlots.endTime,
      title: scheduleSlots.title,
      groupLabel: scheduleSlots.groupLabel,
      room: scheduleSlots.room,
      activityName: activities.name,
      activitySlug: activities.slug,
      activityColor: activities.color,
      teacherName: teamMembers.name,
    })
    .from(scheduleSlots)
    .leftJoin(activities, eq(scheduleSlots.activityId, activities.id))
    .leftJoin(teamMembers, eq(scheduleSlots.teacherId, teamMembers.id))
    .where(eq(scheduleSlots.seasonId, seasonId))
    .orderBy(asc(scheduleSlots.weekday), asc(scheduleSlots.startTime));
  return rows.map((r) => ({
    id: r.id,
    weekday: r.weekday,
    startTime: r.startTime,
    endTime: r.endTime,
    title: r.title || r.activityName || "Занимание",
    activitySlug: r.activitySlug,
    color: r.activityColor || "#7C5CFF",
    teacher: r.teacherName || "",
    groupLabel: r.groupLabel,
    room: r.room,
  }));
}

// ---------- Събития ----------
/** Предстоящи: не архивирани и (крайната или началната дата) >= днес. */
export async function getUpcomingEvents(limit?: number) {
  const today = todayISO();
  const q = db
    .select()
    .from(events)
    .where(
      and(
        eq(events.visible, true),
        eq(events.archived, false),
        or(gte(events.endsOn, today), and(sql`${events.endsOn} is null`, gte(events.startsOn, today))),
      ),
    )
    .orderBy(asc(events.startsOn));
  return limit ? q.limit(limit) : q;
}

/** Отминали: архивирани ръчно или с изтекла дата. */
export async function getPastEvents(limit = 50) {
  const today = todayISO();
  return db
    .select()
    .from(events)
    .where(
      and(
        eq(events.visible, true),
        or(
          eq(events.archived, true),
          lt(events.endsOn, today),
          and(sql`${events.endsOn} is null`, lt(events.startsOn, today)),
        ),
      ),
    )
    .orderBy(desc(events.startsOn))
    .limit(limit);
}

export async function getEventBySlug(slug: string) {
  const [e] = await db.select().from(events).where(eq(events.slug, slug)).limit(1);
  return e ?? null;
}

export function isEventPast(e: { startsOn: string; endsOn: string | null; archived: boolean }): boolean {
  const today = todayISO();
  return e.archived || (e.endsOn ? e.endsOn < today : e.startsOn < today);
}

// ---------- Новини ----------
export async function getPublishedPosts(limit?: number) {
  const q = db
    .select()
    .from(posts)
    .where(and(isNotNull(posts.publishedAt), sql`${posts.publishedAt} <= now()`))
    .orderBy(desc(posts.publishedAt));
  return limit ? q.limit(limit) : q;
}

export async function getPostBySlug(slug: string) {
  const [p] = await db.select().from(posts).where(eq(posts.slug, slug)).limit(1);
  return p ?? null;
}
