import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Оптимистична проверка: без сесийна бисквитка → към входа. Истинската проверка е в admin layout-а.
export function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const open = pathname === "/admin/login" || pathname === "/admin/setup";
  if (!open && !request.cookies.get("bb_session")) {
    const url = request.nextUrl.clone();
    url.pathname = "/admin/login";
    url.search = "";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/admin/:path*"] };
